# Halo geocenter baseline

The original scenario and both original CSV fixtures are retained here. Five
RA/Dec measurements span eight days, with 10 arcsecond angular noise and a
geocenter observer, using Earth-Moon CR3BP dynamics.

From the repository root after installing both packages:

```text
collocation-iod-stack --config scenarios/halo_geocenter/config.yaml --estimation none --propagator cr3bp
```

Omit the last two options for Orekit refinement/propagation, with Java and
`OREKIT_DATA` configured. `cislunar-stack` uses the configured range-search IOD;
`collocation-iod-stack` selects collocation. Reports go to `outputs/halo_geocenter`.

Truth is used for grading; `truth_plus_error` remains an explicitly selectable
test initializer. The current runner still needs truth for its normal report
files; removing that coupling is separate work. The preserved pre-reorganization
integrated results are in `outputs/collocation-original/stack`.

All paths in the YAML resolve relative to the YAML. CLI path overrides resolve
from the calling directory. Original observation and truth CSV contents have not
been changed. Running `simulation/obs_generator.py` writes new data to
`outputs/synthetic_generation` and does not overwrite these fixtures.
