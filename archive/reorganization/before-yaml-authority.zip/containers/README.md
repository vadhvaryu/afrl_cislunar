# Containers

Both application recipes use the **repository root** as build context:

```text
docker build -f containers/Dockerfile -t cislunar-stack .
docker run --rm cislunar-stack
docker build -f containers/Dockerfile.solver -t collocation-iod .
docker run --rm collocation-iod
```

The full-stack image installs both Python packages and bundles the halo scenario,
Java, and leap-second data. Reports go to `/output`; mount a host directory there
to retain them. For example, in PowerShell:

```powershell
docker run --rm -v "${PWD}/outputs/container:/output" cislunar-stack
```

The solver image contains only the standalone numerical solver and its example
CSV. Its optional `--target orekit` adds Java/Orekit interoperability. Both
recipes retain their build-time numerical smoke checks. Docker is unavailable in
the current workspace, so these updated recipes still require actual build and
runtime verification on a Docker-enabled machine.

The old Orekit tutorial container is preserved separately in
`examples/orekit_tutorials`; it is not the full pipeline image.
