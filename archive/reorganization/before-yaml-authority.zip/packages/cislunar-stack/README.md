# Cislunar simulation stack

Install from the repository root:

```text
python -m pip install -e "./packages/cislunar-stack[orekit,test,examples]"
python -m pip install -e "./packages/collocation-iod[test]"
cislunar-stack --config scenarios/halo_geocenter/config.yaml
collocation-iod-stack --config scenarios/halo_geocenter/config.yaml
```

Orekit requires a supported Java runtime and `OREKIT_DATA`. The bundled synthetic
scenario can use `packages/collocation-iod/data/orekit`. For a Java-free run:

```text
collocation-iod-stack --config scenarios/halo_geocenter/config.yaml --estimation none --propagator cr3bp
```

Use an absolute config path to run from any directory. Paths inside configuration
files resolve relative to that file; CLI path overrides resolve from the current
directory. The default scenario writes to `outputs/halo_geocenter`.

The numerical core lives in `src/od_stack`. The original shared CR3BP/STM code
is preserved as `od_stack.reference_cr3bp`; examples import it from the installed
package. Synthetic generation lives in `../../simulation` and input fixtures in
`../../scenarios`, outside the installable product.

See [the detailed pipeline documentation](src/od_stack/README.md) and
[repository layout](../../docs/repository_layout.md). This reorganization does
not change estimator physics or add the still-pending update workflow.
