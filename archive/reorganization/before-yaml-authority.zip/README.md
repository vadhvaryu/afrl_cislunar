# AFRL cislunar orbit determination

Fall 2026 project: containerized software for generating and updating cislunar
orbit paths from synthetic sensor data.

The repository contains a working CR3BP batch orbit-determination prototype and
an independently packaged collocation IOD solver. Sequential updating and broader
product validation remain unfinished; see [project status](docs/project_status.md).

## Repository layout

| Directory | Responsibility |
|---|---|
| [packages/cislunar-stack](packages/cislunar-stack/README.md) | Installable observation -> IOD -> estimation -> propagation pipeline |
| [packages/collocation-iod](packages/collocation-iod/README.md) | Standalone numerical solver and optional stack adapter |
| [scenarios](scenarios/halo_geocenter/README.md) | Scenario configuration, observations, and grading truth |
| [simulation](simulation/README.md) | Synthetic observation generation |
| [examples](examples/README.md) | Weber, Artemis, STM, and Orekit tutorial cases |
| [containers](containers/README.md) | Full-product and standalone-solver Docker recipes |
| [benchmarks](benchmarks/README.md) | Validation entry point and future experiment location |
| [archive](archive/README.md) | Preserved scripts, figures, artifacts, and exact pre-migration files |
| `outputs/` | Generated reports; ignored by Git |

## Install and run

From the repository root, with a Python environment active:

```text
python -m pip install -e "./packages/cislunar-stack[orekit,test,examples]"
python -m pip install -e "./packages/collocation-iod[test]"
collocation-iod-stack --config scenarios/halo_geocenter/config.yaml --estimation none --propagator cr3bp
```

This runs without Java and writes to `outputs/halo_geocenter`. For the full Orekit
chain, use a supported Java runtime (the verification was run with Java 21):

```text
python packages/collocation-iod/examples/verify_stack.py --run-tests
```

Use `--java-home PATH` if necessary. This verification command configures the
bundled synthetic Orekit data and writes to `outputs/stack`. For normal Orekit
CLI runs, configure `JAVA_HOME` and set `OREKIT_DATA` to the absolute path of
`packages/collocation-iod/data/orekit`, then omit the Java-free method overrides.
`cislunar-stack` selects the config's IOD (range search by default);
`collocation-iod-stack` selects collocation.

Config file paths resolve relative to the config file. CLI path overrides resolve
from the current directory. An absolute config path works outside the repository.
The current pipeline still requires truth to write its normal report files.

## Container

```text
docker build -f containers/Dockerfile -t cislunar-stack .
docker run --rm cislunar-stack
```

Build from the repository root. See [container documentation](containers/README.md)
for output mounts and the standalone solver image. Docker build/runtime validation
remains pending because Docker is unavailable in this workspace.

See [migration details](docs/repository_layout.md) for the old-to-new path map,
preservation guarantees, and validation. No original project files were discarded.
