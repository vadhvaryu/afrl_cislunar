# Synthetic simulation tools

The original observation-generator code is preserved in `obs_generator.py`.
Install `packages/cislunar-stack` first, then run from the repository root:

```text
python simulation/obs_generator.py
```

It writes observations, truth, and a plot under `outputs/synthetic_generation`.
Its original numerical settings remain at the top of the script. It is still an
executable script with module-level work, not a side-effect-free library API.
For headless execution, set `MPLBACKEND=Agg`.

Truth-based pipeline evaluation remains in `od_stack.results` and
`od_stack.sources`; extracting that functionality is separate from this layout
change. No evaluator code was discarded.
