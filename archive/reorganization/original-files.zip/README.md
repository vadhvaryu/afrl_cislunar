# AFRL cislunar orbit determination

Fall 2026 project: containerized software for generating and updating cislunar
orbit paths from synthetic sensor data.

The repository currently contains a working CR3BP batch orbit-determination
prototype, an independently packaged collocation IOD solver, and exploratory
simulation cases. Updating estimates as observations arrive and validating the
deployable product remain unfinished.

| Area | Location | Role |
|---|---|---|
| Simulation/OD pipeline | [afrl_cislunar/od_stack](afrl_cislunar/od_stack/README.md) | Observations, IOD, Orekit batch least squares, propagation, and results |
| Collocation solver | [collocation_iod](collocation_iod/README.md) | Standalone IOD and maneuver reconstruction; optional stack adapter |
| Synthetic baseline | `afrl_cislunar/obs_generator.py`, `afrl_cislunar/config.yaml`, `afrl_cislunar/data/synthetic_*.csv` | Existing five-observation demonstration and truth for grading |
| Exploratory cases | `afrl_cislunar/artemis2_vs_cr3bp.py`, `weber_cr3bp_example.py`, `stm_check.py` | Dynamics comparisons and numerical checks |
| Full-stack container recipe | `collocation_iod/Dockerfile.stack` | Packages the synthetic pipeline; build/runtime validation still needed |
| Orekit tutorial container | [docker/orekit-cr3bp](docker/orekit-cr3bp/README.md) | Separate tutorial demonstration |

See [project status and cleanup plan](docs/project_status.md) for the assessment
against the AFRL guideline, outstanding deliverables, and the proposed product
layout. The older `afrl_cislunar/README.md` describes early work; its TODO list
does not reflect all current capabilities.

For existing installation and execution commands, use the stack and collocation
READMEs linked above. Their current working-directory requirements still apply.
